import { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '../../lib/supabase'

type Overview = {
  summary: {
    played: number
    wins: number
    losses: number
    win_rate: number
    games_for: number
    games_against: number
    games_diff: number
  }
  bySeason: Array<{
    season_id: string
    season_name: string
    year: number | null
    played: number
    wins: number
    losses: number
    win_rate: number
    games_for: number
    games_against: number
    games_diff: number
    total_points: number
    stages_played: number
  }>
  byStage: Array<{
    stage_id: number
    stage_name: string
    stage_date: string | null
    season_id: string
    season_name: string
    played: number
    wins: number
    losses: number
    win_rate: number
    games_for: number
    games_against: number
    games_diff: number
    stage_points: number | null
    stage_position: number | null
  }>
  lastMatches: Array<{
    match_id: string
    season_id: string
    season_name: string
    stage_id: number
    stage_name: string
    round_id: string
    round_name: string
    round_no: number | null
    court_no: number
    slot_no: number
    ended_at: string | null
    team_label: string
    opp_label: string
    games_for: number
    games_against: number
    result: 'W' | 'L' | 'T'
  }>
}

type BestPartner = {
  partner_label: string | null
  played: number
  wins: number
  losses: number
  win_rate: number
  games_for: number
  games_against: number
  games_diff: number
}

function pct(n: number) {
  const x = Number(n)
  return Number.isFinite(x) ? `${x.toFixed(1)}%` : '0.0%'
}

function fmtDT(s: string | null) {
  if (!s) return '—'
  try {
    return new Date(s).toLocaleString()
  } catch {
    return s
  }
}

function StatCard({ label, value }: { label: string; value: string | number }) {
  return (
    <div className='card p-4'>
      <div className='text-xs text-slate-300'>{label}</div>
      <div className='text-2xl font-extrabold tracking-tight'>{value}</div>
    </div>
  )
}

function StatCardSub({
  label,
  value,
  sub,
}: {
  label: string
  value: string | number
  sub?: string
}) {
  return (
    <div className='card p-4'>
      <div className='text-xs text-slate-300'>{label}</div>
      <div className='text-2xl font-extrabold tracking-tight'>{value}</div>
      {sub ? <div className='text-xs text-slate-300 mt-1'>{sub}</div> : null}
    </div>
  )
}

export default function AthleteAnalyticsPage() {
  const nav = useNavigate()
  const [loading, setLoading] = useState(true)
  const [err, setErr] = useState<string | null>(null)
  const [data, setData] = useState<Overview | null>(null)
  const [bestPartner, setBestPartner] = useState<BestPartner | null>(null)

  async function load() {
    setLoading(true)
    setErr(null)

    const [ov, bp] = await Promise.all([
      supabase.rpc('athlete_analytics_overview', { p_season_id: null }),
      supabase.rpc('athlete_analytics_best_partner', { p_season_id: null }),
    ])

    if (ov.error) {
      setErr(ov.error.message)
      setData(null)
      setBestPartner(null)
      setLoading(false)
      return
    }

    // best partner é opcional; se falhar, não quebra a tela
    if (bp.error) {
      setBestPartner(null)
    } else {
      setBestPartner((bp.data as BestPartner) ?? null)
    }

    setData(ov.data as Overview)
    setLoading(false)
  }

  useEffect(() => {
    load()

    const ch = supabase
      .channel('athlete-analytics-matches')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'matches' }, () => load())
      .subscribe()

    return () => {
      supabase.removeChannel(ch)
    }
  }, [])

  const stagesSorted = useMemo(() => {
    const arr = data?.byStage ? [...data.byStage] : []
    arr.sort((a, b) => (b.stage_id ?? 0) - (a.stage_id ?? 0))
    return arr
  }, [data])

  if (loading) return <div className='card p-4'>Carregando Analytics...</div>
  if (err) return <div className='card p-4 text-red-200'>Erro: {err}</div>
  if (!data) return <div className='card p-4'>Sem dados.</div>

  return (
    <div className='space-y-6'>
      <div className='card p-4'>
        <div className='text-sm text-slate-300'>Desempenho geral</div>
        <div className='text-2xl font-extrabold tracking-tight'>Analytics</div>
      </div>

      <div className='grid gap-3 md:grid-cols-4'>
        <StatCard label='Jogos' value={data.summary.played} />
        <StatCard label='Vitórias' value={data.summary.wins} />
        <StatCard label='Derrotas' value={data.summary.losses} />
        <StatCard label='Win rate' value={pct(data.summary.win_rate)} />
      </div>

      <div className='grid gap-3 md:grid-cols-3'>
        <StatCard label='Games pró' value={data.summary.games_for} />
        <StatCard label='Games contra' value={data.summary.games_against} />
        <StatCard label='Saldo' value={data.summary.games_diff} />
      </div>

      <div className='card p-4'>
        <div className='text-lg font-bold mb-2'>Melhor dupla do atleta</div>
        <div className='text-xs text-slate-300 mb-3'>
          Baseado no histórico de jogos <b>played</b>, considerando o parceiro que mais rendeu (vitórias e desempenho).
        </div>

        {bestPartner?.partner_label ? (
          <div className='grid gap-3 md:grid-cols-4'>
            <StatCardSub
              label='Parceiro'
              value={bestPartner.partner_label}
              sub={`${bestPartner.played} jogo(s) juntos`}
            />
            <StatCard label='Vitórias' value={bestPartner.wins} />
            <StatCard label='Derrotas' value={bestPartner.losses} />
            <StatCard label='Win rate' value={pct(bestPartner.win_rate)} />
            <StatCard label='Games pró' value={bestPartner.games_for} />
            <StatCard label='Games contra' value={bestPartner.games_against} />
            <StatCard label='Saldo' value={bestPartner.games_diff} />
          </div>
        ) : (
          <div className='text-sm text-slate-200'>Ainda não há jogos suficientes para calcular a melhor dupla.</div>
        )}
      </div>

      <div className='card p-4'>
        <div className='text-lg font-bold mb-3'>Temporadas</div>
        <div className='overflow-x-auto'>
          <table className='w-full text-sm'>
            <thead className='text-slate-300'>
              <tr className='border-b border-white/10'>
                <th className='text-left py-2 pr-3'>Temporada</th>
                <th className='text-right py-2 px-2'>Pontos</th>
                <th className='text-right py-2 px-2'>Etapas</th>
                <th className='text-right py-2 px-2'>Jogos</th>
                <th className='text-right py-2 px-2'>V</th>
                <th className='text-right py-2 px-2'>D</th>
                <th className='text-right py-2 px-2'>Win%</th>
                <th className='text-right py-2 pl-2'>Saldo</th>
              </tr>
            </thead>
            <tbody>
              {data.bySeason.map((s) => (
                <tr key={s.season_id} className='border-b border-white/5'>
                  <td className='py-2 pr-3'>{s.season_name}</td>
                  <td className='py-2 px-2 text-right'>{s.total_points}</td>
                  <td className='py-2 px-2 text-right'>{s.stages_played}</td>
                  <td className='py-2 px-2 text-right'>{s.played}</td>
                  <td className='py-2 px-2 text-right'>{s.wins}</td>
                  <td className='py-2 px-2 text-right'>{s.losses}</td>
                  <td className='py-2 px-2 text-right'>{pct(s.win_rate)}</td>
                  <td className='py-2 pl-2 text-right'>{s.games_diff}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className='card p-4'>
        <div className='text-lg font-bold mb-3'>Etapas</div>
        <div className='text-xs text-slate-300 mb-3'>
          Clique em uma etapa para ver o detalhamento (jogos + posição + pontos).
        </div>

        <div className='overflow-x-auto'>
          <table className='w-full text-sm'>
            <thead className='text-slate-300'>
              <tr className='border-b border-white/10'>
                <th className='text-left py-2 pr-3'>Etapa</th>
                <th className='text-left py-2 pr-3'>Temporada</th>
                <th className='text-right py-2 px-2'>Jogos</th>
                <th className='text-right py-2 px-2'>V</th>
                <th className='text-right py-2 px-2'>D</th>
                <th className='text-right py-2 px-2'>Win%</th>
                <th className='text-right py-2 px-2'>Saldo</th>
                <th className='text-right py-2 px-2'>Pontos</th>
                <th className='text-right py-2 pl-2'>Posição</th>
              </tr>
            </thead>
            <tbody>
              {stagesSorted.map((st) => (
                <tr
                  key={st.stage_id}
                  className='border-b border-white/5 hover:bg-white/5 cursor-pointer'
                  onClick={() => nav(`/athlete/analytics/stage/${st.stage_id}`)}
                >
                  <td className='py-2 pr-3'>{st.stage_name}</td>
                  <td className='py-2 pr-3'>{st.season_name}</td>
                  <td className='py-2 px-2 text-right'>{st.played}</td>
                  <td className='py-2 px-2 text-right'>{st.wins}</td>
                  <td className='py-2 px-2 text-right'>{st.losses}</td>
                  <td className='py-2 px-2 text-right'>{pct(st.win_rate)}</td>
                  <td className='py-2 px-2 text-right'>{st.games_diff}</td>
                  <td className='py-2 px-2 text-right'>{st.stage_points ?? '—'}</td>
                  <td className='py-2 pl-2 text-right'>{st.stage_position ?? '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className='card p-4'>
        <div className='text-lg font-bold mb-3'>Últimos jogos</div>
        <div className='overflow-x-auto'>
          <table className='w-full text-sm'>
            <thead className='text-slate-300'>
              <tr className='border-b border-white/10'>
                <th className='text-left py-2 pr-3'>Res</th>
                <th className='text-left py-2 pr-3'>Etapa</th>
                <th className='text-left py-2 pr-3'>Rodada</th>
                <th className='text-right py-2 px-2'>Quadra</th>
                <th className='text-right py-2 px-2'>Slot</th>
                <th className='text-left py-2 pr-3'>Dupla</th>
                <th className='text-left py-2 pr-3'>Adversários</th>
                <th className='text-right py-2 px-2'>Placar</th>
                <th className='text-left py-2 pl-2'>Fim</th>
              </tr>
            </thead>
            <tbody>
              {data.lastMatches.map((m) => (
                <tr key={m.match_id} className='border-b border-white/5'>
                  <td className='py-2 pr-3 font-bold'>{m.result}</td>
                  <td className='py-2 pr-3'>{m.stage_name}</td>
                  <td className='py-2 pr-3'>{m.round_name}</td>
                  <td className='py-2 px-2 text-right'>{m.court_no}</td>
                  <td className='py-2 px-2 text-right'>{m.slot_no}</td>
                  <td className='py-2 pr-3'>{m.team_label}</td>
                  <td className='py-2 pr-3'>{m.opp_label}</td>
                  <td className='py-2 px-2 text-right'>
                    {m.games_for} x {m.games_against}
                  </td>
                  <td className='py-2 pl-2'>{fmtDT(m.ended_at)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
