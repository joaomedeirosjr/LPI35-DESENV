import { useEffect, useMemo, useState } from 'react'
import * as React from "react"
import { useNavigate } from 'react-router-dom'
import { supabase } from '../../lib/supabase'
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceLine,
} from "recharts"


type FallbackBestPartner = {
  partner_label: string
  played: number
  wins: number
  losses: number
  win_rate: number
  games_for: number
  games_against: number
  games_diff: number
}

function computeBestPartnerFromMatches(args: {
  athleteName: string | null
  lastMatches: Array<{
    team_label: string
    result: string
    games_for: number
    games_against: number
  }>
}): FallbackBestPartner | null {
  const athlete = (args.athleteName ?? "").trim()
  if (!athlete) return null

  const agg = new Map<string, { played: number; wins: number; losses: number; gf: number; ga: number }>()

  for (const m of args.lastMatches ?? []) {
    const parts = (m.team_label ?? "")
      .split(" + ")
      .map((x) => x.trim())
      .filter(Boolean)
    if (parts.length !== 2) continue

    let partner: string | null = null
    if (parts[0] === athlete) partner = parts[1]
    else if (parts[1] === athlete) partner = parts[0]
    else {
      if (parts[0].includes(athlete)) partner = parts[1]
      else if (parts[1].includes(athlete)) partner = parts[0]
      else continue
    }

    const a = agg.get(partner) ?? { played: 0, wins: 0, losses: 0, gf: 0, ga: 0 }
    a.played += 1
    if (m.result === "W") a.wins += 1
    else if (m.result === "L") a.losses += 1
    a.gf += Number(m.games_for ?? 0)
    a.ga += Number(m.games_against ?? 0)
    agg.set(partner, a)
  }

  if (agg.size === 0) return null

  let best: { partner: string; a: any } | null = null
  for (const [partner, a] of agg.entries()) {
    const winRate = a.played > 0 ? (a.wins / a.played) * 100 : 0
    const diff = a.gf - a.ga
    if (!best) best = { partner, a: { ...a, winRate, diff } }
    else {
      const b = best.a
      const better =
        a.wins > b.wins ||
        (a.wins === b.wins && winRate > b.winRate) ||
        (a.wins === b.wins && winRate === b.winRate && diff > b.diff) ||
        (a.wins === b.wins && winRate === b.winRate && diff === b.diff && a.played > b.played) ||
        (a.wins === b.wins && winRate === b.winRate && diff === b.diff && a.played === b.played && partner < best.partner)
      if (better) best = { partner, a: { ...a, winRate, diff } }
    }
  }

  if (!best) return null
  return {
    partner_label: best.partner,
    played: best.a.played,
    wins: best.a.wins,
    losses: best.a.losses,
    win_rate: Number(best.a.winRate.toFixed(1)),
    games_for: best.a.gf,
    games_against: best.a.ga,
    games_diff: best.a.diff,
  }
}


type Overview = {
  summary: {
    played: number
    wins: number
    losses: number
    win_rate: number
    games_for: number
    games_against: number
    games_diff: number
  }
  bySeason: Array<{
    season_id: string
    season_name: string
    year: number | null
    played: number
    wins: number
    losses: number
    win_rate: number
    games_for: number
    games_against: number
    games_diff: number
    total_points: number
    stages_played: number
  }>
  byStage: Array<{
    stage_id: number
    stage_name: string
    club_name: string | null
    stage_date: string | null
    season_id: string
    season_name: string
    played: number
    wins: number
    losses: number
    win_rate: number
    games_for: number
    games_against: number
    games_diff: number
    stage_points: number | null
    stage_position: number | null
  }>
  lastMatches: Array<{
    match_id: string
    season_id: string
    season_name: string
    stage_id: number
    stage_name: string
    club_name: string | null
    round_id: string
    round_name: string
    round_no: number | null
    court_no: number
    slot_no: number
    ended_at: string | null
    team_label: string
    opp_label: string
    games_for: number
    games_against: number
    result: 'W' | 'L' | 'T'
  }>
}

type BestPartner = {
  partner_label: string | null
  played: number
  wins: number
  losses: number
  win_rate: number
  games_for: number
  games_against: number
  games_diff: number
}

type ResultIconInfo = { label: string; kind: 'win' | 'loss' | 'tie' }

function resultIcon(r: string): ResultIconInfo {
  if (r === 'W') return { label: 'V', kind: 'win' }
  if (r === 'L') return { label: 'D', kind: 'loss' }
  return { label: r, kind: 'tie' }
}

function ResIcon({ kind }: { kind: ResultIconInfo['kind'] }) {
  // no external deps; simple inline SVGs
  if (kind === 'win') {
    return (
      <svg width="16" height="16" viewBox="0 0 24 24" aria-hidden="true">
        <path
          fill="currentColor"
          d="M12 2a10 10 0 1 0 0 20a10 10 0 0 0 0-20Zm-1 14l-4-4l1.4-1.4L11 13.2l5.6-5.6L18 9l-7 7Z"
        />
      </svg>
    )
  }
  if (kind === 'loss') {
    return (
      <svg width="16" height="16" viewBox="0 0 24 24" aria-hidden="true">
        <path
          fill="currentColor"
          d="M12 2a10 10 0 1 0 0 20a10 10 0 0 0 0-20Zm3.7 13.3L13.4 13l2.3-2.3L14.3 9.3L12 11.6L9.7 9.3L8.3 10.7L10.6 13l-2.3 2.3l1.4 1.4L12 14.4l2.3 2.3l1.4-1.4Z"
        />
      </svg>
    )
  }
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" aria-hidden="true">
      <path
        fill="currentColor"
        d="M12 2a10 10 0 1 0 0 20a10 10 0 0 0 0-20Zm-5 11h10v-2H7v2Z"
      />
    </svg>
  )
}


function pct(n: number) {
  const x = Number(n)
  return Number.isFinite(x) ? `${x.toFixed(1)}%` : '0.0%'
}

function fmtDT(s: string | null) {
  if (!s) return '—'
  try {
    return new Date(s).toLocaleString()
  } catch {
    return s
  }
}

function StatCard({ label, value }: { label: string; value: string | number }) {
  return (
    <div className='card p-4'>
      <div className='text-xs text-slate-300'>{label}</div>
      <div className='text-2xl font-extrabold tracking-tight'>{value}</div>
    
        {analytics?.byStage?.length ? (
          <div className="mt-4">
            <StageEvolutionProChart byStage={analytics.byStage} />
          </div>
        ) : null}

</div>
  )
}

function StatCardSub({
  label,
  value,
  sub,
}: {
  label: string
  value: string | number
  sub?: string
}) {
  return (
    <div className='card p-4'>
      <div className='text-xs text-slate-300'>{label}</div>
      <div className='text-2xl font-extrabold tracking-tight'>{value}</div>
      {sub ? <div className='text-xs text-slate-300 mt-1'>{sub}</div> : null}
    </div>
  )
}

type EvoMetric = "points" | "win_rate" | "position"

function fmtPct(v: number) {
  if (!isFinite(v)) return "0%"
  return `${v.toFixed(1)}%`
}

function formatStageLabel(name: string) {
  const n = (name ?? "").trim()
  return n.length > 18 ? n.slice(0, 18) + "…" : n
}

function EvoTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null
  const d = payload[0]?.payload as any
  return (
    <div className="rounded-xl border border-white/10 bg-slate-950/90 p-3 shadow-2xl backdrop-blur">
      <div className="text-sm font-semibold text-white">{d.fullLabel ?? label}</div>
      <div className="mt-1 text-xs text-slate-300">{d.club ? `Clube: ${d.club}` : "Clube: —"}</div>

      <div className="mt-2 grid grid-cols-2 gap-x-4 gap-y-1 text-xs">
        <div className="text-slate-300">Pontos</div>
        <div className="text-right font-semibold text-white">{d.points}</div>

        <div className="text-slate-300">Posição</div>
        <div className="text-right font-semibold text-white">#{d.position}</div>

        <div className="text-slate-300">Win rate</div>
        <div className="text-right font-semibold text-white">{fmtPct(d.winRate)}</div>

        <div className="text-slate-300">W–L</div>
        <div className="text-right font-semibold text-white">
          {d.wins}–{d.losses} ({d.played})
        </div>

        <div className="text-slate-300">Saldo</div>
        <div className="text-right font-semibold text-white">{d.gamesDiff}</div>
      </div>
    </div>
  )
}

function StageEvolutionProChart({ byStage }: { byStage: any[] }) {
  const [metric, setMetric] = React.useState<EvoMetric>("points")

  const data = React.useMemo(() => {
    const rows = [...(byStage ?? [])]
    rows.sort((a, b) => {
      const ad = a.stage_date ? new Date(a.stage_date).getTime() : 0
      const bd = b.stage_date ? new Date(b.stage_date).getTime() : 0
      if (ad && bd && ad !== bd) return ad - bd
      return (a.stage_id ?? 0) - (b.stage_id ?? 0)
    })

    return rows.map((s) => ({
      key: s.stage_id,
      label: formatStageLabel(s.stage_name ?? ""),
      fullLabel: s.stage_name ?? "",
      club: s.club_name ?? s.club ?? null,
      points: Number(s.stage_points ?? 0),
      position: Number(s.stage_position ?? 0),
      winRate: Number(s.win_rate ?? 0),
      wins: Number(s.wins ?? 0),
      losses: Number(s.losses ?? 0),
      played: Number(s.played ?? 0),
      gamesDiff: Number(s.games_diff ?? 0),
    }))
  }, [byStage])

  const summary = React.useMemo(() => {
    if (!data.length) return null
    const last = data[data.length - 1]
    const avgWin = data.reduce((acc, x) => acc + x.winRate, 0) / data.length
    const bestPoints = Math.max(...data.map((x) => x.points))
    const bestWin = Math.max(...data.map((x) => x.winRate))
    return { last, avgWin, bestPoints, bestWin }
  }, [data])

  const yDomain = React.useMemo(() => {
    if (!data.length) return [0, 10]
    if (metric === "points") {
      const max = Math.max(...data.map((x) => x.points))
      return [0, Math.max(10, max + 2)]
    }
    if (metric === "win_rate") return [0, 100]
    const maxPos = Math.max(...data.map((x) => x.position))
    return [1, Math.max(2, maxPos)]
  }, [data, metric])

  const metricLabel = metric === "points" ? "Pontos" : metric === "win_rate" ? "Win rate" : "Posição"
  const metricKey = metric === "points" ? "points" : metric === "win_rate" ? "winRate" : "position"

  if (!data.length) {
    return (
      <div className="rounded-2xl border border-white/10 bg-white/5 p-6">
        <div className="text-sm text-slate-300">Sem dados suficientes para mostrar evolução por etapa.</div>
      </div>
    )
  }

  const yAxisProps =
    metric === "position"
      ? { reversed: true, tickFormatter: (v: any) => `#${v}` }
      : metric === "win_rate"
      ? { tickFormatter: (v: any) => `${v}%` }
      : {}

  return (
    <div className="rounded-2xl border border-white/10 bg-gradient-to-b from-white/5 to-white/0 p-5 shadow-[0_0_0_1px_rgba(255,255,255,0.06),0_30px_80px_rgba(0,0,0,0.35)]">
      <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
        <div>
          <div className="text-lg font-semibold text-white">Evolução por etapa</div>
          <div className="text-xs text-slate-300">Performance ao longo das etapas (pontos, win rate e posição).</div>

          <div className="mt-3 inline-flex rounded-xl border border-white/10 bg-white/5 p-1">
            <button
              className={`px-3 py-1.5 text-xs rounded-lg ${metric === "points" ? "bg-white/10 text-white" : "text-slate-300 hover:text-white"}`}
              onClick={() => setMetric("points")}
              type="button"
            >
              Pontos
            </button>
            <button
              className={`px-3 py-1.5 text-xs rounded-lg ${metric === "win_rate" ? "bg-white/10 text-white" : "text-slate-300 hover:text-white"}`}
              onClick={() => setMetric("win_rate")}
              type="button"
            >
              Win rate
            </button>
            <button
              className={`px-3 py-1.5 text-xs rounded-lg ${metric === "position" ? "bg-white/10 text-white" : "text-slate-300 hover:text-white"}`}
              onClick={() => setMetric("position")}
              type="button"
            >
              Posição
            </button>
          </div>
        </div>

        {summary ? (
          <div className="flex flex-wrap gap-2 justify-end">
            <div className="rounded-lg border border-white/10 bg-white/5 px-3 py-2">
              <div className="text-[10px] uppercase tracking-wide text-slate-400">Última etapa</div>
              <div className="text-sm font-semibold text-white">
                {summary.last.fullLabel}{" "}
                <span className="text-slate-300 font-medium">
                  (#{summary.last.position}, {summary.last.points} pts, {fmtPct(summary.last.winRate)})
                </span>
              </div>
            </div>

            <div className="rounded-lg border border-white/10 bg-white/5 px-3 py-2">
              <div className="text-[10px] uppercase tracking-wide text-slate-400">Média win rate</div>
              <div className="text-sm font-semibold text-white">{fmtPct(summary.avgWin)}</div>
            </div>

            <div className="rounded-lg border border-white/10 bg-white/5 px-3 py-2">
              <div className="text-[10px] uppercase tracking-wide text-slate-400">Melhor</div>
              <div className="text-sm font-semibold text-white">
                {summary.bestPoints} pts • {fmtPct(summary.bestWin)}
              </div>
            </div>
          </div>
        ) : null}
      </div>

      <div className="mt-4 h-[360px]">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data} margin={{ top: 10, right: 16, left: 0, bottom: 0 }}>
            <defs>
              <linearGradient id="evoFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="currentColor" stopOpacity={0.35} />
                <stop offset="95%" stopColor="currentColor" stopOpacity={0.0} />
              </linearGradient>
            </defs>

            <CartesianGrid stroke="rgba(255,255,255,0.08)" vertical={false} />
            <XAxis
              dataKey="label"
              tick={{ fill: "rgba(226,232,240,0.75)", fontSize: 12 }}
              axisLine={{ stroke: "rgba(255,255,255,0.10)" }}
              tickLine={false}
              interval={0}
              height={50}
            />
            <YAxis
              domain={yDomain as any}
              tick={{ fill: "rgba(226,232,240,0.75)", fontSize: 12 }}
              axisLine={{ stroke: "rgba(255,255,255,0.10)" }}
              tickLine={false}
              width={52}
              {...(yAxisProps as any)}
            />

            <Tooltip content={<EvoTooltip />} />

            {metric === "win_rate" && summary ? (
              <ReferenceLine y={summary.avgWin} stroke="rgba(255,255,255,0.25)" strokeDasharray="4 4" />
            ) : null}

            <g className="text-emerald-400">
              <Area
                type="monotone"
                dataKey={metricKey}
                stroke="currentColor"
                fill="url(#evoFill)"
                strokeWidth={2.6}
                dot={{ r: 3, fill: "currentColor", stroke: "rgba(15,23,42,0.9)", strokeWidth: 2 }}
                activeDot={{ r: 6, fill: "currentColor", stroke: "rgba(15,23,42,0.9)", strokeWidth: 2 }}
              />
              <Line type="monotone" dataKey={metricKey} stroke="currentColor" strokeWidth={2.6} dot={false} />
            </g>

            {metric !== "win_rate" ? (
              <g className="text-sky-400">
                <Line type="monotone" dataKey="winRate" stroke="currentColor" strokeWidth={1.6} strokeOpacity={0.35} dot={false} />
              </g>
            ) : null}
          </AreaChart>
        </ResponsiveContainer>
      </div>

      <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-300">
        <div>
          <span className="font-semibold text-white">{metricLabel}</span>{" "}
          <span className="text-slate-400">•</span> clique para alternar
        </div>
        <div className="text-slate-400">Dica: passe o mouse/toque nos pontos para detalhes</div>
      </div>
    </div>
  )
}


export default function AthleteAnalyticsPage() {
  const nav = useNavigate()
  const [loading, setLoading] = useState(true)
  const [err, setErr] = useState<string | null>(null)
  const [data, setData] = useState<Overview | null>(null)
  const [bestPartner, setBestPartner] = useState<BestPartner | null>(null)
  const [athleteName, setAthleteName] = useState<string | null>(null)

  async function load() {
    setLoading(true)
    setErr(null)

    // nome do atleta logado (para melhor dupla; parceiro pode ser convidado)
    let athleteNameLocal: string | null = null
    const u = await supabase.auth.getUser()
    const uid = u.data.user?.id ?? null
    if (uid) {
      const pn = await supabase.from('profiles').select('nome').eq('id', uid).maybeSingle()
      athleteNameLocal = ((pn.data as any)?.nome ?? null)
      setAthleteName(athleteNameLocal)
    }

    const [ov, bp] = await Promise.all([
      supabase.rpc('athlete_analytics_overview', { p_season_id: null }),
      supabase.rpc('athlete_analytics_best_partner', { p_season_id: null }),
    ])

    if (ov.error) {
      setErr(ov.error.message)
      setData(null)
      setBestPartner(null)
      setLoading(false)
      return
    }

    // best partner é opcional; se falhar, não quebra a tela
    if (bp.error) {
      setBestPartner(null)
    } else {
      setBestPartner((bp.data as BestPartner) ?? null)
    }

    setData(ov.data as Overview)

    // melhor dupla (prioriza RPC; fallback para convidado via lastMatches)
    const ovData = ov.data as any
    const bpData = (bp.data as any) ?? null
    const bpPartner = bpData?.partner_label ?? bpData?.partner_name ?? bpData?.partner ?? null
    if (bpPartner) {
      setBestPartner(bpData)
    } else {
      const fb = computeBestPartnerFromMatches({
        athleteName: athleteNameLocal ?? athleteName,
        lastMatches: (ovData?.lastMatches ?? []) as any,
      })
      setBestPartner((fb ?? null) as any)
    }
    setLoading(false)
  }

  useEffect(() => {
    load()

    const ch = supabase
      .channel('athlete-analytics-matches')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'matches' }, () => load())
      .subscribe()

    return () => {
      supabase.removeChannel(ch)
    }
  }, [])

  const stagesSorted = useMemo(() => {
    const arr = data?.byStage ? [...data.byStage] : []
    arr.sort((a, b) => (b.stage_id ?? 0) - (a.stage_id ?? 0))
    return arr
  }, [data])

  if (loading) return <div className='card p-4'>Carregando Analytics...</div>
  if (err) return <div className='card p-4 text-red-200'>Erro: {err}</div>
  if (!data) return <div className='card p-4'>Sem dados.</div>

  return (
    <div className='space-y-6'>
      <div className='card p-4'>
        <div className='text-sm text-slate-300'>Desempenho geral</div>
        <div className='text-2xl font-extrabold tracking-tight'>Analytics</div>
      </div>

      <div className='grid gap-3 md:grid-cols-4'>
        <StatCard label='Jogos' value={data.summary.played} />
        <StatCard label='Vitórias' value={data.summary.wins} />
        <StatCard label='Derrotas' value={data.summary.losses} />
        <StatCard label='Win rate' value={pct(data.summary.win_rate)} />
      </div>

      <div className='grid gap-3 md:grid-cols-3'>
        <StatCard label='Games pró' value={data.summary.games_for} />
        <StatCard label='Games contra' value={data.summary.games_against} />
        <StatCard label='Saldo' value={data.summary.games_diff} />
      </div>

      <div className='card p-4'>
        <div className='text-lg font-bold mb-2'>Melhor dupla do atleta</div>
        <div className='text-xs text-slate-300 mb-3'>
          Baseado no histórico de jogos <b>played</b>, considerando o parceiro que mais rendeu (vitórias e desempenho).
        </div>

        {bestPartner?.partner_label ? (
          <div className='grid gap-3 md:grid-cols-4'>
            <StatCardSub
              label='Parceiro'
              value={bestPartner.partner_label}
              sub={`${bestPartner.played} jogo(s) juntos`}
            />
            <StatCard label='Vitórias' value={bestPartner.wins} />
            <StatCard label='Derrotas' value={bestPartner.losses} />
            <StatCard label='Win rate' value={pct(bestPartner.win_rate)} />
            <StatCard label='Games pró' value={bestPartner.games_for} />
            <StatCard label='Games contra' value={bestPartner.games_against} />
            <StatCard label='Saldo' value={bestPartner.games_diff} />
          </div>
        ) : (
          <div className='text-sm text-slate-200'>Ainda não foi possível calcular a melhor dupla (dados insuficientes ou parceiro não identificado).</div>
        )}
      </div>

      <div className='card p-4'>
        <div className='text-lg font-bold mb-3'>Temporadas</div>
        <div className='overflow-x-auto'>
          <table className='w-full text-sm'>
            <thead className='text-slate-300'>
              <tr className='border-b border-white/10'>
                <th className='text-left py-2 pr-3'>Temporada</th>
                <th className='text-right py-2 px-2'>Pontos</th>
                <th className='text-right py-2 px-2'>Etapas</th>
                <th className='text-right py-2 px-2'>Jogos</th>
                <th className='text-right py-2 px-2'>V</th>
                <th className='text-right py-2 px-2'>D</th>
                <th className='text-right py-2 px-2'>Win%</th>
                <th className='text-right py-2 pl-2'>Saldo</th>
              </tr>
            </thead>
            <tbody>
              {data.bySeason.map((s) => (
                <tr key={s.season_id} className='border-b border-white/5'>
                  <td className='py-2 pr-3'>{s.season_name}</td>
                  <td className='py-2 px-2 text-right'>{s.total_points}</td>
                  <td className='py-2 px-2 text-right'>{s.stages_played}</td>
                  <td className='py-2 px-2 text-right'>{s.played}</td>
                  <td className='py-2 px-2 text-right'>{s.wins}</td>
                  <td className='py-2 px-2 text-right'>{s.losses}</td>
                  <td className='py-2 px-2 text-right'>{pct(s.win_rate)}</td>
                  <td className='py-2 pl-2 text-right'>{s.games_diff}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className='card p-4'>
        <div className='text-lg font-bold mb-3'>Etapas</div>
        <div className='text-xs text-slate-300 mb-3'>
          Clique em uma etapa para ver o detalhamento (jogos + posição + pontos).
        </div>

        <div className='overflow-x-auto'>
          <table className='w-full text-sm'>
            <thead className='text-slate-300'>
              <tr className='border-b border-white/10'>
                <th className='text-left py-2 pr-3'>Etapa</th>
                <th className='text-left py-2 pr-3'>Temporada</th>
                <th className='text-right py-2 px-2'>Jogos</th>
                <th className='text-right py-2 px-2'>V</th>
                <th className='text-right py-2 px-2'>D</th>
                <th className='text-right py-2 px-2'>Win%</th>
                <th className='text-right py-2 px-2'>Saldo</th>
                <th className='text-right py-2 px-2'>Pontos</th>
                <th className='text-right py-2 pl-2'>Posição</th>
              </tr>
            </thead>
            <tbody>
              {stagesSorted.map((st) => (
                <tr
                  key={st.stage_id}
                  className='border-b border-white/5 hover:bg-white/5 cursor-pointer'
                  onClick={() => nav(`/athlete/analytics/stage/${st.stage_id}`)}
                >
                  <td className='py-2 pr-3'>{st.stage_name}</td>
                  <td className='py-2 pr-3'>{st.season_name}</td>
                  <td className='py-2 px-2 text-right'>{st.played}</td>
                  <td className='py-2 px-2 text-right'>{st.wins}</td>
                  <td className='py-2 px-2 text-right'>{st.losses}</td>
                  <td className='py-2 px-2 text-right'>{pct(st.win_rate)}</td>
                  <td className='py-2 px-2 text-right'>{st.games_diff}</td>
                  <td className='py-2 px-2 text-right'>{st.stage_points ?? '—'}</td>
                  <td className='py-2 pl-2 text-right'>{st.stage_position ?? '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className='card p-4'>
        <div className='text-lg font-bold mb-3'>Últimos jogos</div>
        <div className='overflow-x-auto'>
          <table className='w-full text-sm'>
            <thead className='text-slate-300'>
              <tr className='border-b border-white/10'>
                <th className='text-left py-2 pr-3'>Res</th>
                <th className='text-left py-2 pr-3'>Clube</th>
                <th className='text-left py-2 pr-3'>Etapa</th>
                <th className='text-left py-2 pr-3'>Dupla</th>
                <th className='text-left py-2 pr-3'>Adversários</th>
                <th className='text-right py-2 px-2'>Placar</th>
                <th className='text-left py-2 pl-2'>Fim</th>
              </tr>
            </thead>
            <tbody>
              {data.lastMatches.map((m) => (
                <tr key={m.match_id} className='border-b border-white/5'>
                  <td className='py-2 pr-3 font-bold'>
                    {(() => {
                      const r = resultIcon(m.result)
                      return (
                        <span className='inline-flex items-center gap-2'>
                          <span className={r.kind === 'win' ? 'text-emerald-400' : r.kind === 'loss' ? 'text-rose-400' : 'text-slate-300'}>
                          <ResIcon kind={r.kind} />
                        </span>
                          <span>{r.label}</span>
                        </span>
                      )
                    })()}</td>
                  <td className='py-2 pr-3'>{m.club_name ?? '—'}</td>
                  <td className='py-2 pr-3'>{m.stage_name}</td>
                  <td className='py-2 pr-3'>{m.team_label}</td>
                  <td className='py-2 pr-3'>{m.opp_label}</td>
                  <td className='py-2 px-2 text-right'>
                    {m.games_for} x {m.games_against}
                  </td>
                  <td className='py-2 pl-2'>{fmtDT(m.ended_at)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
